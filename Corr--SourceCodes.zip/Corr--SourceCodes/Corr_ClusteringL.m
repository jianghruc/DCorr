function  clusters=Corr_ClusteringL(A,optnumber,Labels)


N = size(A,1);           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Positive indice and negative indice for construction
 DSim_PN = zeros(N,N);   
   for n1 = 1 : N 
          m=mean(A(setdiff(1:N,n1),:));
         IND_DF(n1,:) = ((A(n1,:)-m)>0)-((A(n1,:)-m)<0);
end

for n1=1:N
    for n2=n1+1:N
         Posind=find(IND_DF(n1,:)-IND_DF(n2,:)==0 & IND_DF(n1,:)==1);
         Negind=find(IND_DF(n1,:)-IND_DF(n2,:)==0 & IND_DF(n1,:)==-1);
         DSim_PN(n1,n2) = pdist([IND_DF(n1,:);IND_DF(n2,:)],'correlation');
    end
end

Dissim = DSim_PN+DSim_PN';
for i = 1 : N
    Dissim(i,i)=0;
end


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Clustering Analysis
  Dist=squareform(Dissim);
  clustTreeEuc = linkage(Dist,'ward');   
  clusters = cluster(clustTreeEuc,'MaxClust',optnumber);
  [h0,nodes0] = dendrogram(clustTreeEuc,0,'labels',Labels,'ColorThreshold','default');
  set(h0,'LineWidth',0.4)
  rotateticklabel(gca,90)




 
