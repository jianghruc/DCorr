%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Large Scale Clustering using Corr 
load A_human;
load Labels_human;
optnumber = Number_Large(A);
clusters=Corr_ClusteringL(A,optnumber,Labels);


