function  [optnumber]=Number_Corr(A)

  N = size(A,1);     
        fnumber=size(A,2);     
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Positive indice and negative indice for construction

    Sim_PN = zeros(N,N);
    DSim_PN = zeros(N,N);
    for n1 = 1 : N
        for n2 =n1+1 : N
              m=mean(A(setdiff(1:N,[n1,n2]),:));
              st=std(A(setdiff(1:N,[n1,n2]),:));
             IND_DF(n1,:) = ((A(n1,:)-m)>0)-((A(n1,:)-m)<0);
             IND_DF(n2,:) = ((A(n2,:)-m)>0)-((A(n2,:)-m)<0);
             Posind=find(IND_DF(n1,:)-IND_DF(n2,:)==0 & IND_DF(n1,:)==1);
             Negind=find(IND_DF(n1,:)-IND_DF(n2,:)==0 & IND_DF(n1,:)==-1);
             DSim_PN(n1,n2) = pdist([IND_DF(n1,:);IND_DF(n2,:)],'correlation');
        end
    end

    Dissim = DSim_PN+DSim_PN';
    for i = 1 : N
        Dissim(i,i)=0;
    end
    Dist=squareform(Dissim);
    
     clustTreeEuc = linkage(Dist,'weighted');
    Sa = zeros(size(A,2),1);
    Se = zeros(size(A,2),1);
    stdA=std(A);
    [B,ind]=sort(-stdA);
    for k=2:10
        c = cluster(clustTreeEuc,'MaxClust',k);
        for j=1:size(A,2)
        [p,anovatab,stat]=anova1(A(:,j)',c,'off');
        Sa(j)=anovatab{2,4};
        Se(j)=anovatab{3,4};
        end
   
       F=Sa./(Sa+Se);
        for l=1:fnumber
             e(k-1,l)=sum(F(ind(1:l)));
        end
    end
    e0=e;
    for l=1:fnumber
        if isempty(find(e(:,l)-[e(2:end,l);e(end,l)]>=0))
            k0(l)=10;
        else
        k0(l)=find(e(:,l)-[e(2:end,l);e(end,l)]>0,1,'first')+1;
        end
    end
    T0=tabulate(k0(1:100));
    optnumber=T0(find(max(T0(:,2))==T0(:,2)),1);