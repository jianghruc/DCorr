%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Small Scale Clustering using Corr 
load A_hcancer;
load Labels_hcancer;
% load A_islet;
% load Labels_islet;
% load A_allioploid;
% load Labels_allioploid;
% load A_mouse;
% load Labels_mouse;
optnumber=Number_Corr(A);
clusters = Corr_Clustering(A,optnumber,Labels);




